--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ar_internal_metadata OWNER TO michalczyz;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE categories (
    id integer NOT NULL,
    name character varying,
    plus_or_minus integer,
    parent_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE categories OWNER TO michalczyz;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: michalczyz
--

CREATE SEQUENCE categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE categories_id_seq OWNER TO michalczyz;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michalczyz
--

ALTER SEQUENCE categories_id_seq OWNED BY categories.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE companies (
    id integer NOT NULL,
    name character varying,
    icon character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE companies OWNER TO michalczyz;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: michalczyz
--

CREATE SEQUENCE companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE companies_id_seq OWNER TO michalczyz;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michalczyz
--

ALTER SEQUENCE companies_id_seq OWNED BY companies.id;


--
-- Name: mail_logs; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE mail_logs (
    id integer NOT NULL,
    lp integer,
    number character varying,
    in_or_out character varying,
    document_date_on date,
    external_number character varying,
    received_on date,
    comment text,
    value_net numeric,
    value_vat numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    category_id integer,
    company_id integer
);


ALTER TABLE mail_logs OWNER TO michalczyz;

--
-- Name: mail_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: michalczyz
--

CREATE SEQUENCE mail_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mail_logs_id_seq OWNER TO michalczyz;

--
-- Name: mail_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michalczyz
--

ALTER SEQUENCE mail_logs_id_seq OWNED BY mail_logs.id;


--
-- Name: mail_logs_lp_seq; Type: SEQUENCE; Schema: public; Owner: michalczyz
--

CREATE SEQUENCE mail_logs_lp_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mail_logs_lp_seq OWNER TO michalczyz;

--
-- Name: mail_logs_lp_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michalczyz
--

ALTER SEQUENCE mail_logs_lp_seq OWNED BY mail_logs.lp;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE reports (
    id integer NOT NULL,
    label character varying,
    lprange int4range,
    pages integer,
    pdf character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    year integer,
    month integer
);


ALTER TABLE reports OWNER TO michalczyz;

--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: michalczyz
--

CREATE SEQUENCE reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reports_id_seq OWNER TO michalczyz;

--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michalczyz
--

ALTER SEQUENCE reports_id_seq OWNED BY reports.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE schema_migrations OWNER TO michalczyz;

--
-- Name: users; Type: TABLE; Schema: public; Owner: michalczyz
--

CREATE TABLE users (
    id integer NOT NULL,
    uid character varying,
    name character varying,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users OWNER TO michalczyz;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: michalczyz
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO michalczyz;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michalczyz
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY categories ALTER COLUMN id SET DEFAULT nextval('categories_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY companies ALTER COLUMN id SET DEFAULT nextval('companies_id_seq'::regclass);


--
-- Name: mail_logs id; Type: DEFAULT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY mail_logs ALTER COLUMN id SET DEFAULT nextval('mail_logs_id_seq'::regclass);


--
-- Name: mail_logs lp; Type: DEFAULT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY mail_logs ALTER COLUMN lp SET DEFAULT nextval('mail_logs_lp_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY reports ALTER COLUMN id SET DEFAULT nextval('reports_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2017-02-15 21:59:33.098243	2017-02-15 21:59:33.098243
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY categories (id, name, plus_or_minus, parent_id, created_at, updated_at) FROM stdin;
1	Toys, Tools & Home 1	1	\N	2017-02-15 21:59:33.594909	2017-02-15 21:59:33.594909
3	Tools 3	1	\N	2017-02-15 21:59:33.6137	2017-02-15 21:59:33.6137
4	Grocery, Garden & Health 4	1	\N	2017-02-15 21:59:33.622173	2017-02-15 21:59:33.622173
5	Music & Automotive 5	1	\N	2017-02-15 21:59:33.630932	2017-02-15 21:59:33.630932
19	Garden & Games	\N	10	2017-02-15 21:59:33.676503	2017-02-15 21:59:33.676503
20	Grocery & Movies	\N	19	2017-02-15 21:59:33.678943	2017-02-15 21:59:33.678943
22	Test Test	\N	10	2017-02-20 18:37:55.815559	2017-02-20 18:37:55.815559
37	something new	\N	\N	2017-02-20 22:13:29.42658	2017-02-20 22:13:29.42658
36	Tool 4	\N	32	2017-02-20 22:13:10.601778	2017-02-20 22:15:45.231599
32	Baby 10	\N	3	2017-02-20 19:30:24.180035	2017-02-20 22:15:57.712196
2	Baby 2	1	18	2017-02-15 21:59:33.605176	2017-03-01 21:24:28.876354
39	test test test 	\N	\N	2017-03-03 17:43:09.413203	2017-03-03 17:43:09.413203
40	one two three	\N	\N	2017-03-03 17:45:24.545697	2017-03-03 17:45:24.545697
18	Health	\N	\N	2017-02-15 21:59:33.674007	2017-02-15 21:59:33.674007
10	Computers & Music 10	1	\N	2017-02-15 21:59:33.644848	2017-02-21 00:03:48.532245
11	Games, Tools & Health	\N	\N	2017-02-15 21:59:33.653732	2017-02-15 21:59:33.653732
38	Oh baby 113	\N	\N	2017-02-20 23:50:41.042255	2017-02-20 23:50:41.042255
14	Kids, Health & Toys	\N	\N	2017-02-15 21:59:33.662015	2017-02-15 21:59:33.662015
24	and with her	\N	\N	2017-02-20 18:40:24.757642	2017-02-20 18:40:24.757642
41	one two three 	\N	\N	2017-03-03 17:50:22.555495	2017-03-03 17:50:22.555495
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michalczyz
--

SELECT pg_catalog.setval('categories_id_seq', 41, true);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY companies (id, name, icon, created_at, updated_at) FROM stdin;
1	Rodriguez, Ernser and Schmitt 1	\N	2017-02-15 21:59:33.583899	2017-02-15 21:59:33.583899
2	McGlynn LLC 2	\N	2017-02-15 21:59:33.603079	2017-02-15 21:59:33.603079
4	Price-Vandervort 4	\N	2017-02-15 21:59:33.618879	2017-02-15 21:59:33.618879
5	O'Keefe Inc 5	\N	2017-02-15 21:59:33.628702	2017-02-15 21:59:33.628702
6	selleo	\N	2017-02-16 15:02:30.053644	2017-02-16 15:02:30.053644
7	selleeo as	\N	2017-02-16 15:06:15.381733	2017-02-16 15:06:15.381733
3	Selleo Inc.	\N	2017-02-15 21:59:33.611511	2017-02-22 22:17:34.56469
8	Inc Inc.	\N	2017-02-22 22:18:02.521472	2017-02-22 22:18:02.521472
\.


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michalczyz
--

SELECT pg_catalog.setval('companies_id_seq', 8, true);


--
-- Data for Name: mail_logs; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY mail_logs (id, lp, number, in_or_out, document_date_on, external_number, received_on, comment, value_net, value_vat, created_at, updated_at, category_id, company_id) FROM stdin;
1	1	2017-00001-O	O	2017-02-12	FV/2017/1	2017-02-15	Nihil est illum beatae.	14.03	3.2269	2017-02-15 21:59:33.597999	2017-02-15 21:59:33.597999	1	1
2	2	2017-00002-O	O	2017-02-12	FV/2017/2	2017-02-15	Est sunt dolore aut voluptatum perspiciatis eius id.	42.44	9.7612	2017-02-15 21:59:33.606796	2017-02-15 21:59:33.606796	2	2
5	5	2017-00005-O	O	2017-02-12	FV/2017/5	2017-02-15	Est qui facere velit aliquam similique.	62.32	14.3336	2017-02-15 21:59:33.632665	2017-02-15 21:59:33.632665	5	5
6	6	2017-00006-O	O	2017-02-16	some number	2017-02-16	\N	\N	\N	2017-02-16 15:02:42.707997	2017-02-16 15:02:42.707997	10	6
3	3	2017-00003-O	O	2017-02-12	FV/2017/3	2017-02-15	Non enim ut temporibus unde nihil consequatur voluptate.	65.97	15.1731	2017-02-15 21:59:33.615088	2017-02-20 19:50:12.291786	2	3
4	4	2017-00004-O	O	2017-02-12	FV/2017/4	2017-02-15	Nostrum perspiciatis deserunt culpa sed incidunt molestias impedit.	17.04	3.9192	2017-02-15 21:59:33.624091	2017-03-01 21:23:48.258307	4	3
\.


--
-- Name: mail_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michalczyz
--

SELECT pg_catalog.setval('mail_logs_id_seq', 6, true);


--
-- Name: mail_logs_lp_seq; Type: SEQUENCE SET; Schema: public; Owner: michalczyz
--

SELECT pg_catalog.setval('mail_logs_lp_seq', 6, true);


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY reports (id, label, lprange, pages, pdf, created_at, updated_at, year, month) FROM stdin;
3	March 2017	\N	\N	03-March.pdf	2017-02-22 21:58:26.921137	2017-02-22 21:58:27.540015	2017	3
4	December 2017	\N	\N	12-December.pdf	2017-02-22 22:44:19.369881	2017-02-22 22:44:20.634564	2017	12
1	January 2017	\N	\N	01-January.pdf	2017-02-22 21:36:48.846433	2017-02-22 22:49:13.901066	2017	1
2	February 2017	\N	\N	02-February.pdf	2017-02-22 21:39:10.728158	2017-03-01 21:24:07.301108	2017	2
\.


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michalczyz
--

SELECT pg_catalog.setval('reports_id_seq', 4, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY schema_migrations (version) FROM stdin;
20170124100514
20170125103929
20170127133759
20170127163226
20170201111856
20170201112013
20170206131543
20170206173431
20170210172029
20170215164814
20170215175326
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: michalczyz
--

COPY users (id, uid, name, email, created_at, updated_at) FROM stdin;
1	google-oauth2|116315098232069288327	\N	\N	2017-02-16 14:42:53.303254	2017-02-16 14:42:53.303254
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michalczyz
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: mail_logs mail_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY mail_logs
    ADD CONSTRAINT mail_logs_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_categories_on_parent_id; Type: INDEX; Schema: public; Owner: michalczyz
--

CREATE INDEX index_categories_on_parent_id ON categories USING btree (parent_id);


--
-- Name: index_mail_logs_on_category_id; Type: INDEX; Schema: public; Owner: michalczyz
--

CREATE INDEX index_mail_logs_on_category_id ON mail_logs USING btree (category_id);


--
-- Name: index_mail_logs_on_company_id; Type: INDEX; Schema: public; Owner: michalczyz
--

CREATE INDEX index_mail_logs_on_company_id ON mail_logs USING btree (company_id);


--
-- Name: categories fk_rails_82f48f7407; Type: FK CONSTRAINT; Schema: public; Owner: michalczyz
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT fk_rails_82f48f7407 FOREIGN KEY (parent_id) REFERENCES categories(id);


--
-- PostgreSQL database dump complete
--

